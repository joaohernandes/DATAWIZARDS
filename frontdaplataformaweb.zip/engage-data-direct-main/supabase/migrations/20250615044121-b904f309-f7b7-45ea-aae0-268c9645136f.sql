
-- Criar funções para calcular métricas acadêmicas reais

-- Função para calcular taxa de aprovação geral
CREATE OR REPLACE FUNCTION calcular_taxa_aprovacao()
RETURNS NUMERIC AS $$
DECLARE
    total_matriculas INTEGER;
    aprovados INTEGER;
BEGIN
    SELECT COUNT(*) INTO total_matriculas FROM matricula WHERE situacao IN ('Aprovado', 'Reprovado');
    SELECT COUNT(*) INTO aprovados FROM matricula WHERE situacao = 'Aprovado';
    
    IF total_matriculas = 0 THEN
        RETURN 0;
    END IF;
    
    RETURN ROUND((aprovados::NUMERIC / total_matriculas::NUMERIC) * 100, 1);
END;
$$ LANGUAGE plpgsql;

-- Função para calcular média geral de notas
CREATE OR REPLACE FUNCTION calcular_media_geral()
RETURNS NUMERIC AS $$
DECLARE
    media_geral NUMERIC;
BEGIN
    SELECT ROUND(AVG(valor), 2) INTO media_geral FROM nota;
    RETURN COALESCE(media_geral, 0);
END;
$$ LANGUAGE plpgsql;

-- Função para calcular taxa de frequência
CREATE OR REPLACE FUNCTION calcular_taxa_frequencia()
RETURNS NUMERIC AS $$
DECLARE
    total_aulas INTEGER;
    presencas INTEGER;
BEGIN
    SELECT COUNT(*) INTO total_aulas FROM frequencia;
    SELECT COUNT(*) INTO presencas FROM frequencia WHERE presente = true;
    
    IF total_aulas = 0 THEN
        RETURN 0;
    END IF;
    
    RETURN ROUND((presencas::NUMERIC / total_aulas::NUMERIC) * 100, 1);
END;
$$ LANGUAGE plpgsql;

-- Função para contar alunos em risco
CREATE OR REPLACE FUNCTION contar_alunos_risco()
RETURNS INTEGER AS $$
DECLARE
    alunos_risco INTEGER;
BEGIN
    -- Alunos com frequência baixa ou notas baixas
    WITH alunos_freq_baixa AS (
        SELECT DISTINCT m.aluno_id
        FROM matricula m
        JOIN frequencia f ON f.matricula_id = m.id
        GROUP BY m.aluno_id
        HAVING (COUNT(CASE WHEN f.presente THEN 1 END)::NUMERIC / COUNT(*)::NUMERIC) < 0.75
    ),
    alunos_nota_baixa AS (
        SELECT DISTINCT m.aluno_id
        FROM matricula m
        JOIN nota n ON n.matricula_id = m.id
        GROUP BY m.aluno_id
        HAVING AVG(n.valor) < 6.0
    )
    SELECT COUNT(DISTINCT aluno_id) INTO alunos_risco
    FROM (
        SELECT aluno_id FROM alunos_freq_baixa
        UNION
        SELECT aluno_id FROM alunos_nota_baixa
    ) AS risco;
    
    RETURN COALESCE(alunos_risco, 0);
END;
$$ LANGUAGE plpgsql;

-- Função para obter performance por departamento
CREATE OR REPLACE FUNCTION obter_performance_departamento()
RETURNS TABLE(
    departamento TEXT,
    media_notas NUMERIC,
    frequencia NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        d.nome::TEXT,
        ROUND(AVG(n.valor), 1) as media_notas,
        ROUND(
            (COUNT(CASE WHEN f.presente THEN 1 END)::NUMERIC / 
             COUNT(f.id)::NUMERIC) * 100, 1
        ) as frequencia
    FROM departamento d
    JOIN professor p ON p.departamento_id = d.id
    JOIN turma t ON t.professor_id = p.id
    JOIN matricula m ON m.turma_id = t.id
    LEFT JOIN nota n ON n.matricula_id = m.id
    LEFT JOIN frequencia f ON f.matricula_id = m.id
    GROUP BY d.id, d.nome
    ORDER BY d.nome;
END;
$$ LANGUAGE plpgsql;

-- Função para obter distribuição de situações
CREATE OR REPLACE FUNCTION obter_distribuicao_situacoes()
RETURNS TABLE(
    situacao TEXT,
    quantidade INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.situacao::TEXT,
        COUNT(*)::INTEGER
    FROM matricula m
    GROUP BY m.situacao
    ORDER BY COUNT(*) DESC;
END;
$$ LANGUAGE plpgsql;
