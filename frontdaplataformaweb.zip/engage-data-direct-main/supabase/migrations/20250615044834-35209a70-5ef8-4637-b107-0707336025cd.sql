
-- Função para obter dados das turmas com informações básicas
CREATE OR REPLACE FUNCTION obter_turmas_resumo()
RETURNS TABLE(
    turma_id INTEGER,
    codigo_turma TEXT,
    nome_curso TEXT,
    nome_professor TEXT,
    semestre TEXT,
    total_alunos INTEGER,
    media_turma NUMERIC,
    taxa_frequencia_turma NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.id::INTEGER,
        t.codigo::TEXT,
        c.nome::TEXT,
        p.nome::TEXT,
        t.semestre::TEXT,
        COUNT(DISTINCT m.aluno_id)::INTEGER as total_alunos,
        ROUND(AVG(n.valor), 2) as media_turma,
        ROUND(
            (COUNT(CASE WHEN f.presente THEN 1 END)::NUMERIC / 
             NULLIF(COUNT(f.id), 0)::NUMERIC) * 100, 1
        ) as taxa_frequencia_turma
    FROM turma t
    JOIN curso c ON c.id = t.curso_id
    JOIN professor p ON p.id = t.professor_id
    LEFT JOIN matricula m ON m.turma_id = t.id
    LEFT JOIN nota n ON n.matricula_id = m.id
    LEFT JOIN frequencia f ON f.matricula_id = m.id
    GROUP BY t.id, t.codigo, c.nome, p.nome, t.semestre
    ORDER BY t.semestre DESC, t.codigo;
END;
$$ LANGUAGE plpgsql;

-- Função para obter alunos de uma turma específica
CREATE OR REPLACE FUNCTION obter_alunos_turma(turma_id_param INTEGER)
RETURNS TABLE(
    aluno_id INTEGER,
    nome_aluno TEXT,
    matricula_aluno TEXT,
    situacao TEXT,
    media_aluno NUMERIC,
    frequencia_aluno NUMERIC,
    data_matricula TIMESTAMP
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id::INTEGER,
        a.nome::TEXT,
        a.matricula::TEXT,
        m.situacao::TEXT,
        ROUND(AVG(n.valor), 2) as media_aluno,
        ROUND(
            (COUNT(CASE WHEN f.presente THEN 1 END)::NUMERIC / 
             NULLIF(COUNT(f.id), 0)::NUMERIC) * 100, 1
        ) as frequencia_aluno,
        m.data_matricula
    FROM aluno a
    JOIN matricula m ON m.aluno_id = a.id
    LEFT JOIN nota n ON n.matricula_id = m.id
    LEFT JOIN frequencia f ON f.matricula_id = m.id
    WHERE m.turma_id = turma_id_param
    GROUP BY a.id, a.nome, a.matricula, m.situacao, m.data_matricula
    ORDER BY a.nome;
END;
$$ LANGUAGE plpgsql;
