export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      agente: {
        Row: {
          created_at: string
          etiqueta: string | null
          id: number
          idmensagem: string | null
          nomecliente: string | null
          sessionid: string | null
          telefonecliente: string | null
        }
        Insert: {
          created_at?: string
          etiqueta?: string | null
          id?: never
          idmensagem?: string | null
          nomecliente?: string | null
          sessionid?: string | null
          telefonecliente?: string | null
        }
        Update: {
          created_at?: string
          etiqueta?: string | null
          id?: never
          idmensagem?: string | null
          nomecliente?: string | null
          sessionid?: string | null
          telefonecliente?: string | null
        }
        Relationships: []
      }
      aluno: {
        Row: {
          data_nascimento: string | null
          email: string
          id: number
          ingresso_semestre: string
          matricula: string
          nome: string
        }
        Insert: {
          data_nascimento?: string | null
          email: string
          id?: number
          ingresso_semestre: string
          matricula: string
          nome: string
        }
        Update: {
          data_nascimento?: string | null
          email?: string
          id?: number
          ingresso_semestre?: string
          matricula?: string
          nome?: string
        }
        Relationships: []
      }
      curso: {
        Row: {
          codigo: string
          departamento_id: number
          duracao_semestres: number
          id: number
          nome: string
        }
        Insert: {
          codigo: string
          departamento_id: number
          duracao_semestres: number
          id?: number
          nome: string
        }
        Update: {
          codigo?: string
          departamento_id?: number
          duracao_semestres?: number
          id?: number
          nome?: string
        }
        Relationships: [
          {
            foreignKeyName: "curso_departamento_id_fkey"
            columns: ["departamento_id"]
            isOneToOne: false
            referencedRelation: "departamento"
            referencedColumns: ["id"]
          },
        ]
      }
      dados_cliente: {
        Row: {
          criado_em: string | null
          id: string
          nome: string | null
          session_id: string | null
          telefone: string
        }
        Insert: {
          criado_em?: string | null
          id?: string
          nome?: string | null
          session_id?: string | null
          telefone: string
        }
        Update: {
          criado_em?: string | null
          id?: string
          nome?: string | null
          session_id?: string | null
          telefone?: string
        }
        Relationships: []
      }
      dados_vinhos: {
        Row: {
          descricao: string | null
          id: string
          imagem_url: string | null
          valor: string
          vinho: string
        }
        Insert: {
          descricao?: string | null
          id?: string
          imagem_url?: string | null
          valor: string
          vinho: string
        }
        Update: {
          descricao?: string | null
          id?: string
          imagem_url?: string | null
          valor?: string
          vinho?: string
        }
        Relationships: []
      }
      departamento: {
        Row: {
          codigo: string
          id: number
          nome: string
        }
        Insert: {
          codigo: string
          id?: number
          nome: string
        }
        Update: {
          codigo?: string
          id?: number
          nome?: string
        }
        Relationships: []
      }
      documents: {
        Row: {
          content: string | null
          embedding: string | null
          id: number
          metadata: Json | null
        }
        Insert: {
          content?: string | null
          embedding?: string | null
          id?: number
          metadata?: Json | null
        }
        Update: {
          content?: string | null
          embedding?: string | null
          id?: number
          metadata?: Json | null
        }
        Relationships: []
      }
      feedback_professor: {
        Row: {
          data_feedback: string
          id: number
          matricula_id: number
          nota_geral: number | null
          texto: string
        }
        Insert: {
          data_feedback?: string
          id?: number
          matricula_id: number
          nota_geral?: number | null
          texto: string
        }
        Update: {
          data_feedback?: string
          id?: number
          matricula_id?: number
          nota_geral?: number | null
          texto?: string
        }
        Relationships: [
          {
            foreignKeyName: "feedback_professor_matricula_id_fkey"
            columns: ["matricula_id"]
            isOneToOne: false
            referencedRelation: "matricula"
            referencedColumns: ["id"]
          },
        ]
      }
      frequencia: {
        Row: {
          curso_id: number
          data_aula: string
          id: number
          matricula_id: number
          presente: boolean
        }
        Insert: {
          curso_id: number
          data_aula: string
          id?: number
          matricula_id: number
          presente: boolean
        }
        Update: {
          curso_id?: number
          data_aula?: string
          id?: number
          matricula_id?: number
          presente?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "frequencia_curso_id_fkey"
            columns: ["curso_id"]
            isOneToOne: false
            referencedRelation: "curso"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "frequencia_matricula_id_fkey"
            columns: ["matricula_id"]
            isOneToOne: false
            referencedRelation: "matricula"
            referencedColumns: ["id"]
          },
        ]
      }
      matricula: {
        Row: {
          aluno_id: number
          data_matricula: string
          id: number
          situacao: string
          turma_id: number
        }
        Insert: {
          aluno_id: number
          data_matricula?: string
          id?: number
          situacao: string
          turma_id: number
        }
        Update: {
          aluno_id?: number
          data_matricula?: string
          id?: number
          situacao?: string
          turma_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "matricula_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "aluno"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "matricula_turma_id_fkey"
            columns: ["turma_id"]
            isOneToOne: false
            referencedRelation: "turma"
            referencedColumns: ["id"]
          },
        ]
      }
      n8n_chat_histories: {
        Row: {
          content: string | null
          created_at: string | null
          id: string
          message: Json | null
          role: string | null
          session_id: string
        }
        Insert: {
          content?: string | null
          created_at?: string | null
          id?: string
          message?: Json | null
          role?: string | null
          session_id: string
        }
        Update: {
          content?: string | null
          created_at?: string | null
          id?: string
          message?: Json | null
          role?: string | null
          session_id?: string
        }
        Relationships: []
      }
      n8n_fila_mensagens: {
        Row: {
          id: number
          id_mensagem: string
          mensagem: string
          telefone: string
          timestamp: string
        }
        Insert: {
          id?: number
          id_mensagem: string
          mensagem: string
          telefone: string
          timestamp: string
        }
        Update: {
          id?: number
          id_mensagem?: string
          mensagem?: string
          telefone?: string
          timestamp?: string
        }
        Relationships: []
      }
      n8n_historico_mensagens: {
        Row: {
          created_at: string
          id: number
          message: Json
          session_id: string
        }
        Insert: {
          created_at?: string
          id?: number
          message: Json
          session_id: string
        }
        Update: {
          created_at?: string
          id?: number
          message?: Json
          session_id?: string
        }
        Relationships: []
      }
      nota: {
        Row: {
          id: number
          matricula_id: number
          peso: number
          tipo_avaliacao: string
          valor: number
        }
        Insert: {
          id?: number
          matricula_id: number
          peso: number
          tipo_avaliacao: string
          valor: number
        }
        Update: {
          id?: number
          matricula_id?: number
          peso?: number
          tipo_avaliacao?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "nota_matricula_id_fkey"
            columns: ["matricula_id"]
            isOneToOne: false
            referencedRelation: "matricula"
            referencedColumns: ["id"]
          },
        ]
      }
      pedidos: {
        Row: {
          codigo: string
          created_at: string
          id: string
          nome_cliente: string
          produto: string
          status_produto: string
          telefone_cliente: string
        }
        Insert: {
          codigo: string
          created_at?: string
          id?: string
          nome_cliente: string
          produto: string
          status_produto: string
          telefone_cliente: string
        }
        Update: {
          codigo?: string
          created_at?: string
          id?: string
          nome_cliente?: string
          produto?: string
          status_produto?: string
          telefone_cliente?: string
        }
        Relationships: []
      }
      professor: {
        Row: {
          ativo: boolean | null
          departamento_id: number
          email: string
          id: number
          nome: string
          titulacao: string | null
        }
        Insert: {
          ativo?: boolean | null
          departamento_id: number
          email: string
          id?: number
          nome: string
          titulacao?: string | null
        }
        Update: {
          ativo?: boolean | null
          departamento_id?: number
          email?: string
          id?: number
          nome?: string
          titulacao?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "professor_departamento_id_fkey"
            columns: ["departamento_id"]
            isOneToOne: false
            referencedRelation: "departamento"
            referencedColumns: ["id"]
          },
        ]
      }
      turma: {
        Row: {
          capacidade: number
          codigo: string
          curso_id: number
          id: number
          professor_id: number
          semestre: string
        }
        Insert: {
          capacidade?: number
          codigo: string
          curso_id: number
          id?: number
          professor_id: number
          semestre: string
        }
        Update: {
          capacidade?: number
          codigo?: string
          curso_id?: number
          id?: number
          professor_id?: number
          semestre?: string
        }
        Relationships: [
          {
            foreignKeyName: "turma_curso_id_fkey"
            columns: ["curso_id"]
            isOneToOne: false
            referencedRelation: "curso"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turma_professor_id_fkey"
            columns: ["professor_id"]
            isOneToOne: false
            referencedRelation: "professor"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      binary_quantize: {
        Args: { "": string } | { "": unknown }
        Returns: unknown
      }
      calcular_media_geral: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      calcular_taxa_aprovacao: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      calcular_taxa_frequencia: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      contar_alunos_risco: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      halfvec_avg: {
        Args: { "": number[] }
        Returns: unknown
      }
      halfvec_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      halfvec_send: {
        Args: { "": unknown }
        Returns: string
      }
      halfvec_typmod_in: {
        Args: { "": unknown[] }
        Returns: number
      }
      hnsw_bit_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      hnsw_halfvec_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      hnsw_sparsevec_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      hnswhandler: {
        Args: { "": unknown }
        Returns: unknown
      }
      ivfflat_bit_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      ivfflat_halfvec_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      ivfflathandler: {
        Args: { "": unknown }
        Returns: unknown
      }
      l2_norm: {
        Args: { "": unknown } | { "": unknown }
        Returns: number
      }
      l2_normalize: {
        Args: { "": string } | { "": unknown } | { "": unknown }
        Returns: string
      }
      match_documents: {
        Args: { query_embedding: string; match_count?: number; filter?: Json }
        Returns: {
          id: number
          content: string
          metadata: Json
          embedding: Json
          similarity: number
        }[]
      }
      obter_alunos_turma: {
        Args: { turma_id_param: number }
        Returns: {
          aluno_id: number
          nome_aluno: string
          matricula_aluno: string
          situacao: string
          media_aluno: number
          frequencia_aluno: number
          data_matricula: string
        }[]
      }
      obter_distribuicao_situacoes: {
        Args: Record<PropertyKey, never>
        Returns: {
          situacao: string
          quantidade: number
        }[]
      }
      obter_performance_departamento: {
        Args: Record<PropertyKey, never>
        Returns: {
          departamento: string
          media_notas: number
          frequencia: number
        }[]
      }
      obter_turmas_resumo: {
        Args: Record<PropertyKey, never>
        Returns: {
          turma_id: number
          codigo_turma: string
          nome_curso: string
          nome_professor: string
          semestre: string
          total_alunos: number
          media_turma: number
          taxa_frequencia_turma: number
        }[]
      }
      sparsevec_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      sparsevec_send: {
        Args: { "": unknown }
        Returns: string
      }
      sparsevec_typmod_in: {
        Args: { "": unknown[] }
        Returns: number
      }
      vector_avg: {
        Args: { "": number[] }
        Returns: string
      }
      vector_dims: {
        Args: { "": string } | { "": unknown }
        Returns: number
      }
      vector_norm: {
        Args: { "": string }
        Returns: number
      }
      vector_out: {
        Args: { "": string }
        Returns: unknown
      }
      vector_send: {
        Args: { "": string }
        Returns: string
      }
      vector_typmod_in: {
        Args: { "": unknown[] }
        Returns: number
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
