
import { MetricsCard } from "@/components/MetricsCard";
import { ChartSection } from "@/components/ChartSection";
import { TurmasSection } from "@/components/TurmasSection";
import { GraduationCap, Users, BookOpen } from "lucide-react";
import { useAcademicMetrics } from "@/hooks/useAcademicMetrics";
import { useOcupacaoMetrics } from "@/hooks/useOcupacaoMetrics";
import { Skeleton } from "@/components/ui/skeleton";

const Index = () => {
  const { data: metrics, isLoading, error } = useAcademicMetrics();
  const { data: ocupacaoData, isLoading: loadingOcupacao } = useOcupacaoMetrics();

  if (error) {
    console.error("Erro ao carregar métricas:", error);
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard Acadêmico</h1>
        <p className="text-gray-600 mt-2">Informações estratégicas para tomada de decisão da coordenação</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {isLoading || loadingOcupacao ? (
          Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="p-6 border rounded-lg">
              <Skeleton className="h-4 w-32 mb-2" />
              <Skeleton className="h-8 w-20 mb-2" />
              <Skeleton className="h-3 w-24" />
            </div>
          ))
        ) : (
          <>
            <MetricsCard
              title="Taxa de Ocupação"
              value={`${ocupacaoData?.taxaOcupacao ?? 0}%`}
              change={ocupacaoData?.taxaOcupacao !== undefined && ocupacaoData.taxaOcupacao > 0 ? "+ " : ""}
              changeType="neutral"
              description="Média de ocupação das turmas"
              icon={<Users className="w-5 h-5" />}
            />
            <MetricsCard
              title="Média Geral de Notas"
              value={metrics?.mediaGeral?.toString() || "0"}
              change=" "
              changeType="neutral"
              description=""
              icon={<BookOpen className="w-5 h-5" />}
            />
            <MetricsCard
              title="Taxa de Aprovação"
              value={`${metrics?.taxaAprovacao || 0}%`}
              change=" "
              changeType="neutral"
              description=""
              icon={<GraduationCap className="w-5 h-5" />}
            />
            <MetricsCard
              title="Taxa de Frequência"
              value={`${metrics?.taxaFrequencia || 0}%`}
              change=" "
              changeType="neutral"
              description=""
              icon={<Users className="w-5 h-5" />}
            />
          </>
        )}
      </div>

      <div className="grid grid-cols-1 gap-8 mb-8">
        <ChartSection />
        <TurmasSection />
      </div>
    </div>
  );
};

export default Index;
