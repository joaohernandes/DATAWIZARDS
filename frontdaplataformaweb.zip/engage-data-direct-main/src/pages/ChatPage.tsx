import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Send, Download, FileText } from "lucide-react";
import { ChatMessage } from "@/components/ChatMessage";
import { useToast } from "@/hooks/use-toast";
import AudioRecorder from "@/components/AudioRecorder";
import { useChats, Message } from "@/hooks/useChats";
import { ScrollArea } from "@/components/ui/scroll-area";

const ChatPage = () => {
  const { chats, createNewChat, selectChat, addMessageToCurrentChat, getCurrentChat, currentChatId } = useChats();

  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);

  // NOVO: Para PDF
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfFileName, setPdfFileName] = useState<string | null>(null);
  const { toast } = useToast();

  const N8N_WEBHOOK_URL = "https://n8n.grupohernandes.com/webhook/5234fb23-85c7-4ef4-91d1-0f28bf6ddd26";

  // Novo handle para upload de imagem ou PDF
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type.startsWith("image/")) {
      setImageFile(file);
      setImagePreviewUrl(URL.createObjectURL(file));
      setPdfFile(null);
      setPdfFileName(null);
    } else if (file.type === "application/pdf") {
      setPdfFile(file);
      setPdfFileName(file.name);
      setImageFile(null);
      setImagePreviewUrl(null);
    } else {
      toast({
        title: "Tipo de arquivo não suportado",
        description: "Por favor, envie uma imagem ou PDF.",
        variant: "destructive",
      });
    }
  };

  const resetFileInput = () => {
    setImageFile(null);
    setImagePreviewUrl(null);
    setPdfFile(null);
    setPdfFileName(null);
  };

  // Função utilitária para garantir que responseText seja sempre string
  function formatResponseText(output: any): string {
    if (typeof output === "string") return output;
    if (Array.isArray(output)) return output.map(formatResponseText).join("\n\n");
    if (output && typeof output === "object") {
      // Caso seja objeto com 'messages'
      if (Array.isArray(output.messages)) return output.messages.join("\n\n");
      // Qualquer outro objeto: stringifica
      return JSON.stringify(output, null, 2);
    }
    if (output === undefined || output === null) return "";
    return String(output);
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim() && !imageFile && !pdfFile) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isUser: true,
      timestamp: new Date(),
      ...(imagePreviewUrl ? { imageUrl: imagePreviewUrl } : {}),
      ...(pdfFileName ? { pdfFileName } : {}),
    };

    addMessageToCurrentChat(userMessage);
    const currentInput = inputValue;
    setInputValue("");
    setIsLoading(true);

    let imageBase64: string | undefined = undefined;
    if (imageFile) {
      imageBase64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(imageFile);
      });
    }

    let pdfBase64: string | undefined = undefined;
    if (pdfFile) {
      pdfBase64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(pdfFile);
      });
    }

    resetFileInput();

    try {
      console.log("Enviando mensagem para n8n:", currentInput);

      const payload: any = {
        message: currentInput,
        timestamp: new Date().toISOString(),
        user_id: "chat_user",
      };
      if (imageBase64) {
        payload.image = imageBase64;
      }
      if (pdfBase64) {
        payload.pdf = pdfBase64;
        payload.pdfFileName = pdfFileName;
      }

      const response = await fetch(N8N_WEBHOOK_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log("Resposta do n8n:", data);

      let responseText: string = "Desculpe, não consegui processar sua solicitação.";
      let imageUrl;
      let pdfUrl, pdfName;

      // Determina output segundo o formato variado do n8n
      let output;
      if (Array.isArray(data) && data.length > 0 && data[0].output !== undefined) {
        output = data[0].output;
        if (data[0].imageUrl) imageUrl = data[0].imageUrl;
        if (data[0].image) imageUrl = data[0].image;
        if (data[0].pdfUrl) pdfUrl = data[0].pdfUrl;
        if (data[0].pdfFileName) pdfName = data[0].pdfFileName;
      } else if (data.response !== undefined) {
        output = data.response;
        if (data.imageUrl) imageUrl = data.imageUrl;
        if (data.image) imageUrl = data.image;
        if (data.pdfUrl) pdfUrl = data.pdfUrl;
        if (data.pdfFileName) pdfName = data.pdfFileName;
      } else if (data.message !== undefined) {
        output = data.message;
      } else if (typeof data === "string" || Array.isArray(data) || typeof data === "object") {
        output = data;
      }
      responseText = formatResponseText(output);

      let aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: responseText,
        isUser: false,
        timestamp: new Date(),
        ...(imageUrl ? { imageUrl } : {}),
        ...(pdfUrl ? { pdfUrl, pdfFileName: pdfName } : {}),
      };

      if (data.chartData) {
        aiResponse.chartData = data.chartData;
      }

      addMessageToCurrentChat(aiResponse);

    } catch (error) {
      console.error("Erro ao conectar com n8n:", error);

      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "Desculpe, houve um problema ao conectar com o sistema. Tente novamente em alguns instantes.",
        isUser: false,
        timestamp: new Date(),
      };

      addMessageToCurrentChat(errorMessage);

      toast({
        title: "Erro de Conexão",
        description: "Não foi possível conectar com o sistema de IA. Verifique sua conexão.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // NOVO: Enviar áudio processando-o como arquivo base64
  const handleSendAudio = async (audioUrl: string, audioFile: File) => {
    // Mostrar mensagem de usuário com áudio
    const userMessage: Message = {
      id: Date.now().toString(),
      isUser: true,
      timestamp: new Date(),
      audioUrl,
    };
    addMessageToCurrentChat(userMessage);
    setIsLoading(true);

    // Ler arquivo de áudio como base64
    const audioBase64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(audioFile);
    });

    // Enviar para N8N
    try {
      const payload: any = {
        message: "[AUDIO]",
        timestamp: new Date().toISOString(),
        user_id: "chat_user",
        audio: audioBase64,
      };
      const response = await fetch(N8N_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const data = await response.json();

      let responseText = "Áudio recebido!";
      let audioRespUrl;
      if (Array.isArray(data) && data.length > 0 && data[0].output) {
        responseText = data[0].output;
        if (data[0].audioUrl) audioRespUrl = data[0].audioUrl;
      } else if (data.response) {
        responseText = data.response;
        if (data.audioUrl) audioRespUrl = data.audioUrl;
      } else if (typeof data === "string") {
        responseText = data;
      }
      addMessageToCurrentChat({
        id: (Date.now() + 1).toString(),
        isUser: false,
        timestamp: new Date(),
        text: responseText,
        ...(audioRespUrl ? { audioUrl: audioRespUrl } : {}),
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao enviar áudio",
        variant: "destructive",
      });
    }
    setIsLoading(false);
  };

  const handleExportResults = () => {
    toast({
      title: "Exportação Iniciada",
      description: "Seus dados estão sendo preparados para download em CSV.",
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // UI ===
  const currentChat = getCurrentChat();

  return (
    <div className="fixed inset-0 w-full h-full bg-gray-50 flex flex-col">
      {/* Header with chats */}
      <div className="flex flex-col sm:flex-row sm:items-center mb-2 p-2 sm:p-4 bg-white shadow z-20">
        <div className="flex-1 flex flex-col sm:flex-row items-start sm:items-center">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mr-2">Assistente de IA</h1>
          <Button onClick={createNewChat} variant="secondary" size="sm" className="ml-0 sm:ml-4 mb-2 sm:mb-0">
            + Novo Chat
          </Button>
        </div>
        {/* Abas dos chats */}
        <div className="flex flex-wrap gap-1 w-full sm:w-auto mt-2 sm:mt-0">
          {chats.map((c) => (
            <Button
              key={c.id}
              variant={c.id === currentChatId ? "default" : "outline"}
              size="sm"
              onClick={() => selectChat(c.id)}
              className={`transition-all duration-200 ${c.id === currentChatId ? "scale-105 ring-2 ring-primary" : ""}`}
            >
              {c.name}
            </Button>
          ))}
        </div>
      </div>
      
      <p className="text-gray-600 text-sm px-2 sm:px-6 mb-3">Faça perguntas sobre dados acadêmicos em linguagem natural</p>
      
      {/* Card do chat ocupa toda a tela */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Card className="flex-1 flex flex-col rounded-none border-0 shadow-none bg-white/80 backdrop-blur-md h-full">
          {/* Cabeçalho do chat */}
          <CardHeader className="flex-row items-center justify-between border-b border-gray-100/80 bg-gradient-to-r from-blue-50/90 to-white/50 rounded-none py-4 px-4">
            <CardTitle className="text-lg font-semibold text-primary drop-shadow">Chat</CardTitle>
            <Button onClick={() => {toast({title: "Exportação Iniciada", description: "Seus dados estão sendo preparados para download em CSV."});}} variant="ghost" size="sm" className="flex items-center gap-1 text-blue-900">
              <Download className="w-4 h-4 mr-2" />
              Exportar Resultados
            </Button>
          </CardHeader>
          
          {/* Conteúdo do chat: mensagens e input fixo */}
          <CardContent className="flex-1 flex flex-col px-2 sm:px-6 pb-2 bg-transparent overflow-hidden">
            {/* Mensagens com scroll */}
            <ScrollArea className="flex-1 mb-1 pr-1 h-full w-full">
              <div className="flex flex-col gap-4 py-4 pb-36">
                {currentChat?.messages.map((message) => (
                  <div
                    key={message.id}
                    className="animate-fade-in"
                    style={{ animationDuration: "0.35s" }}
                  >
                    <ChatMessage message={message} />
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start animate-fade-in" style={{ animationDuration: "0.45s" }}>
                    <div className="bg-gray-100 rounded-lg px-4 py-2 max-w-xs">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Barra fixa de input */}
            <div className="fixed bottom-0 left-0 w-full z-30 bg-white/80 backdrop-blur-md rounded-none pt-2 pb-2 shadow-[0_-4px_20px_-8px_rgba(30,58,138,0.07)]">
              {/* Audio recorder */}
              <div className="mb-1 px-2 sm:px-6">
                <AudioRecorder onSend={async (...args) => { await handleSendAudio(...args); }} disabled={isLoading} />
              </div>
              {/* Preview de imagem ou PDF */}
              {(imagePreviewUrl || pdfFileName) && (
                <div className="mb-2 flex items-center space-x-4 px-2 sm:px-6">
                  {imagePreviewUrl && (
                    <img
                      src={imagePreviewUrl}
                      alt="Prévia da imagem"
                      className="w-16 h-16 object-cover rounded shadow border"
                    />
                  )}
                  {pdfFileName && (
                    <div className="flex items-center space-x-2 bg-gray-100 px-3 py-2 rounded">
                      <FileText className="text-blue-800 w-6 h-6" />
                      <span className="text-xs text-gray-700 truncate max-w-xs">{pdfFileName}</span>
                    </div>
                  )}
                  <Button variant="outline" type="button" size="sm" onClick={resetFileInput}>
                    Remover
                  </Button>
                </div>
              )}
              {/* Input de texto + upload de imagem/pdf + botão enviar */}
              <div className="flex items-end space-x-2 px-2 sm:px-6">
                <label className="flex items-center px-2 py-1 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition mb-1 select-none">
                  <span className="mr-2 text-gray-500">
                    <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <rect width="18" height="14" x="3" y="5" rx="2"/>
                      <circle cx="9" cy="10" r="2"/>
                      <path d="m21 15-4.35-4.35a2 2 0 0 0-2.83 0L7 18"/>
                    </svg>
                  </span>
                  <span className="mr-1 text-gray-700 font-medium text-xs">Arquivo</span>
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    className="hidden"
                    onChange={handleFileChange}
                    disabled={isLoading}
                  />
                  <span className="ml-2 text-xs text-gray-400">{imageFile ? 'Imagem' : pdfFile ? 'PDF' : ''}</span>
                </label>
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Pergunte sobre frequência, notas, alunos em risco ou qualquer dado acadêmico..."
                  disabled={isLoading}
                  className="flex-1 shadow-inner bg-white/80 rounded-md border border-gray-200"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={isLoading || (!inputValue.trim() && !imageFile && !pdfFile)}
                  className="bg-primary text-white rounded-full w-10 h-10 flex items-center justify-center hover:scale-105 transition-transform"
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ChatPage;
