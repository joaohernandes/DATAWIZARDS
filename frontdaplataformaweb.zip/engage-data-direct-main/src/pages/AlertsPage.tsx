import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Users, TrendingDown, Clock, BookOpen, UserX } from "lucide-react";

const AlertsPage = () => {
  const alerts = [
    {
      id: 1,
      type: "high",
      title: "Frequência Crítica",
      description: "12 alunos em ENG301 com frequência abaixo de 75% (limite legal)",
      timestamp: "2 horas atrás",
      course: "Engenharia Civil - ENG301",
      professor: "Prof. Silva",
      icon: Users,
      action: "Contatar alunos e coordenação",
    },
    {
      id: 2,
      type: "medium",
      title: "Risco de Reprovação",
      description: "Turma ADM201 com média 5.8 - abaixo do limite de aprovação",
      timestamp: "4 horas atrás",
      course: "Administração - ADM201",
      professor: "Prof. Santos",
      icon: TrendingDown,
      action: "Revisar metodologia de ensino",
    },
    {
      id: 3,
      type: "high",
      title: "Padrão de Evasão Detectado",
      description: "15 alunos apresentam comportamento típico de abandono",
      timestamp: "1 dia atrás",
      course: "Múltiplos cursos",
      professor: "Coordenação Acadêmica",
      icon: UserX,
      action: "Intervenção pedagógica urgente",
    },
    {
      id: 4,
      type: "low",
      title: "Avaliação Docente Baixa",
      description: "Prof. Silva recebeu nota 2.8/5.0 na avaliação discente",
      timestamp: "2 dias atrás",
      course: "Matemática I - MAT101",
      professor: "Prof. Silva",
      icon: BookOpen,
      action: "Capacitação pedagógica",
    },
    {
      id: 5,
      type: "medium",
      title: "Alta Taxa de Trancamento",
      description: "Curso de Direito com 8 trancamentos neste semestre",
      timestamp: "3 dias atrás",
      course: "Direito - DIR101",
      professor: "Coordenação de Curso",
      icon: AlertTriangle,
      action: "Análise curricular necessária",
    },
  ];

  const getAlertBadgeColor = (type: string) => {
    switch (type) {
      case "high":
        return "destructive";
      case "medium":
        return "default";
      case "low":
        return "secondary";
      default:
        return "default";
    }
  };

  const getAlertBadgeText = (type: string) => {
    switch (type) {
      case "high":
        return "Crítico";
      case "medium":
        return "Médio";
      case "low":
        return "Baixo";
      default:
        return "Desconhecido";
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "high":
        return "text-red-600 bg-red-100";
      case "medium":
        return "text-yellow-600 bg-yellow-100";
      case "low":
        return "text-blue-600 bg-blue-100";
      default:
        return "text-gray-600 bg-gray-100";
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Alertas e Notificações</h1>
        <p className="text-gray-600 mt-2">Monitore métricas acadêmicas críticas e receba notificações em tempo real</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Alertas Ativos</p>
                <p className="text-2xl font-bold text-gray-900">15</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Críticos</p>
                <p className="text-2xl font-bold text-red-600">3</p>
              </div>
              <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Resolvidos Hoje</p>
                <p className="text-2xl font-bold text-green-600">8</p>
              </div>
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <Users className="w-4 h-4 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Alertas Recentes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {alerts.map((alert) => {
              const Icon = alert.icon;
              return (
                <div key={alert.id} className="flex items-start space-x-4 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex-shrink-0">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getAlertIcon(alert.type)}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="text-sm font-medium text-gray-900">{alert.title}</h3>
                      <Badge variant={getAlertBadgeColor(alert.type) as any}>
                        {getAlertBadgeText(alert.type)}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{alert.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex flex-col space-y-1 text-xs text-gray-500">
                        <span><strong>Curso:</strong> {alert.course}</span>
                        <span><strong>Responsável:</strong> {alert.professor}</span>
                        <span><strong>Ação sugerida:</strong> {alert.action}</span>
                        <span>{alert.timestamp}</span>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          Ver Detalhes
                        </Button>
                        <Button variant="default" size="sm">
                          Marcar como Resolvido
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AlertsPage;
