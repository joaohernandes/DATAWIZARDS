
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const redirectUrl = `${window.location.origin}/`;

type Mode = "login" | "signup";

export default function AuthPage() {
  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    if (mode === "login") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setError(error.message);
      else navigate("/");
    } else {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: redirectUrl }
      });
      setError(
        error
          ? error.message
          : "Cadastro realizado! Por favor, verifique seu e-mail para confirmar."
      );
    }
    setLoading(false);
  };

  return (
    <div className="flex h-screen justify-center items-center bg-gray-50">
      <Card className="max-w-md w-full shadow-lg">
        <CardHeader>
          <CardTitle>
            {mode === "login" ? "Entrar" : "Criar Conta"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={handleSubmit}>
            <Input
              type="email"
              required
              placeholder="E-mail"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
            <Input
              type="password"
              required
              placeholder="Senha"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
            {error && (
              <div className="text-red-500 text-sm">{error}</div>
            )}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading
                ? "Carregando..."
                : mode === "login"
                ? "Entrar"
                : "Criar Conta"}
            </Button>
          </form>
          <div className="text-sm mt-6 text-center">
            {mode === "login" ? (
              <>
                Não tem conta?
                <Button
                  variant="link"
                  className="ml-1 p-0 h-auto align-baseline"
                  onClick={() => setMode("signup")}
                  type="button"
                >
                  Cadastre-se
                </Button>
              </>
            ) : (
              <>
                Já tem conta?
                <Button
                  variant="link"
                  className="ml-1 p-0 h-auto align-baseline"
                  onClick={() => setMode("login")}
                  type="button"
                >
                  Entrar
                </Button>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
