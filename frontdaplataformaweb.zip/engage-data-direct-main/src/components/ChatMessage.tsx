
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface Message {
  id: string;
  text?: string;
  isUser: boolean;
  timestamp: Date;
  chartData?: any;
  imageUrl?: string;
  audioUrl?: string;
}

interface ChatMessageProps {
  message: Message;
}

export const ChatMessage = ({ message }: ChatMessageProps) => {
  return (
    <div className={cn("flex", message.isUser ? "justify-end" : "justify-start")}>
      <div className={cn(
        "max-w-[80%] rounded-lg px-4 py-3",
        message.isUser 
          ? "bg-primary text-white" 
          : "bg-gray-100 text-gray-900"
      )}>
        {/* Mensagem de texto */}
        {message.text && (
          <p className="text-sm">{message.text}</p>
        )}

        {/* Mensagem de imagem */}
        {message.imageUrl && (
          <div className="mt-3 mb-1">
            <img
              src={message.imageUrl}
              alt="imagem enviada"
              className="max-w-xs max-h-64 rounded border object-contain"
              style={{ background: "#fff" }}
            />
          </div>
        )}

        {/* Mensagem de áudio */}
        {message.audioUrl && (
          <div className="mt-2 mb-1">
            <audio controls src={message.audioUrl} className="w-full rounded" />
          </div>
        )}

        {/* Mensagem de gráfico */}
        {message.chartData && (
          <Card className="mt-4 bg-white">
            <CardContent className="p-4">
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={message.chartData.departments.map((dept: string, index: number) => ({
                  department: dept,
                  retention: message.chartData.retentionRates[index]
                }))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="department" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="retention" fill="#1E3A8A" name="Retention %" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        <p className="text-xs opacity-70 mt-2">
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  );
};
