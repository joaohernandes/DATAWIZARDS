
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Users, TrendingDown, UserX, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";

export const AlertsOverview = () => {
  const recentAlerts = [
    {
      id: 1,
      type: "high",
      title: "Frequência Crítica - ENG301",
      description: "12 alunos com frequência abaixo de 75%",
      icon: Users,
      curso: "Engenharia Civil",
    },
    {
      id: 2,
      type: "medium",
      title: "Média Baixa - ADM201",
      description: "Média da turma: 5.8 (risco de reprovação)",
      icon: TrendingDown,
      curso: "Administração",
    },
    {
      id: 3,
      type: "high",
      title: "Alunos em Risco",
      description: "15 alunos com padrão de evasão",
      icon: AlertTriangle,
      curso: "Múltiplos",
    },
    {
      id: 4,
      type: "low",
      title: "Avaliação Professor Baixa",
      description: "Prof. Silva - Nota 2.8/5.0",
      icon: BookOpen,
      curso: "Matemática I",
    },
  ];

  const getAlertColor = (type: string) => {
    switch (type) {
      case "high":
        return "text-red-600";
      case "medium":
        return "text-yellow-600";
      default:
        return "text-gray-600";
    }
  };

  const getAlertBadge = (type: string) => {
    switch (type) {
      case "high":
        return { variant: "destructive" as const, text: "Crítico" };
      case "medium":
        return { variant: "default" as const, text: "Médio" };
      default:
        return { variant: "secondary" as const, text: "Baixo" };
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Alertas Recentes</CardTitle>
        <Link to="/alerts">
          <Button variant="outline" size="sm">Ver Todos</Button>
        </Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentAlerts.map((alert) => {
            const Icon = alert.icon;
            const badge = getAlertBadge(alert.type);
            return (
              <div key={alert.id} className="flex items-start space-x-3 p-3 rounded-lg border hover:bg-gray-50 transition-colors">
                <Icon className={`w-5 h-5 mt-0.5 ${getAlertColor(alert.type)}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-gray-900">{alert.title}</p>
                    <Badge variant={badge.variant}>
                      {badge.text}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-1">{alert.description}</p>
                  <p className="text-xs text-gray-500">{alert.curso}</p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
