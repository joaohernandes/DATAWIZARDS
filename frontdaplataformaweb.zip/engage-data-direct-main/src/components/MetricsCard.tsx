
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface MetricsCardProps {
  title: string;
  value: string;
  change: string;
  changeType: "positive" | "negative" | "neutral";
  description: string;
  icon?: React.ReactNode;
}

export const MetricsCard = ({ title, value, change, changeType, description, icon }: MetricsCardProps) => {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-gray-600">{title}</p>
            {icon && <div className="text-gray-400">{icon}</div>}
          </div>
          <div className="flex items-baseline justify-between">
            <p className="text-3xl font-bold text-gray-900">{value}</p>
            <div className="flex flex-col items-end">
              <span
                className={cn(
                  "text-sm font-medium",
                  changeType === "positive" && "text-green-600",
                  changeType === "negative" && "text-red-600",
                  changeType === "neutral" && "text-gray-600"
                )}
              >
                {change}
              </span>
              <span className="text-xs text-gray-500">{description}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
