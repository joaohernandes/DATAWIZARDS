
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronRight, Users, GraduationCap } from "lucide-react";
import { useTurmasData, useAlunosTurma } from "@/hooks/useTurmasData";

export const TurmasSection = () => {
  const [expandedTurma, setExpandedTurma] = useState<number | null>(null);
  const { data: turmas, isLoading: loadingTurmas, error: errorTurmas } = useTurmasData();
  const { data: alunos, isLoading: loadingAlunos } = useAlunosTurma(expandedTurma);

  if (errorTurmas) {
    console.error("Erro ao carregar turmas:", errorTurmas);
  }

  const toggleTurma = (turmaId: number) => {
    setExpandedTurma(expandedTurma === turmaId ? null : turmaId);
  };

  const getSituacaoColor = (situacao: string) => {
    switch (situacao) {
      case 'Aprovado':
        return 'text-green-600 bg-green-50';
      case 'Reprovado':
        return 'text-red-600 bg-red-50';
      case 'Matriculado':
        return 'text-blue-600 bg-blue-50';
      case 'Trancado':
        return 'text-yellow-600 bg-yellow-50';
      case 'Cancelado':
        return 'text-gray-600 bg-gray-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GraduationCap className="w-5 h-5" />
          Turmas e Alunos
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loadingTurmas ? (
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, index) => (
              <Skeleton key={index} className="h-16 w-full" />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {turmas?.map((turma) => (
              <div key={turma.turmaId} className="border rounded-lg overflow-hidden">
                <Button
                  variant="ghost"
                  className="w-full p-4 h-auto justify-between hover:bg-gray-50"
                  onClick={() => toggleTurma(turma.turmaId)}
                >
                  <div className="flex items-center gap-4 text-left">
                    <div className="flex items-center gap-2">
                      {expandedTurma === turma.turmaId ? (
                        <ChevronDown className="w-4 h-4" />
                      ) : (
                        <ChevronRight className="w-4 h-4" />
                      )}
                      <Users className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-semibold">
                        {turma.codigoTurma} - {turma.nomeCurso}
                      </div>
                      <div className="text-sm text-gray-600">
                        Prof. {turma.nomeProfessor} • {turma.semestre} • {turma.totalAlunos} alunos
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-4 text-sm">
                    <div className="text-center">
                      <div className="text-gray-600">Média</div>
                      <div className="font-semibold">{turma.mediaTurma || 0}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-gray-600">Frequência</div>
                      <div className="font-semibold">{turma.taxaFrequenciaTurma || 0}%</div>
                    </div>
                  </div>
                </Button>

                {expandedTurma === turma.turmaId && (
                  <div className="border-t bg-gray-50 p-4">
                    {loadingAlunos ? (
                      <div className="space-y-2">
                        {Array.from({ length: 3 }).map((_, index) => (
                          <Skeleton key={index} className="h-12 w-full" />
                        ))}
                      </div>
                    ) : (
                      <div className="bg-white rounded-lg overflow-hidden">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Aluno</TableHead>
                              <TableHead>Matrícula</TableHead>
                              <TableHead>Situação</TableHead>
                              <TableHead>Média</TableHead>
                              <TableHead>Frequência</TableHead>
                              <TableHead>Data Matrícula</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {alunos?.length === 0 ? (
                              <TableRow>
                                <TableCell colSpan={6} className="text-center text-gray-500 py-8">
                                  Nenhum aluno encontrado nesta turma
                                </TableCell>
                              </TableRow>
                            ) : (
                              alunos?.map((aluno) => (
                                <TableRow key={aluno.alunoId}>
                                  <TableCell className="font-medium">
                                    {aluno.nomeAluno}
                                  </TableCell>
                                  <TableCell>{aluno.matriculaAluno}</TableCell>
                                  <TableCell>
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSituacaoColor(aluno.situacao)}`}>
                                      {aluno.situacao}
                                    </span>
                                  </TableCell>
                                  <TableCell>
                                    <span className={`font-medium ${
                                      aluno.mediaAluno >= 7 ? 'text-green-600' : 
                                      aluno.mediaAluno >= 6 ? 'text-yellow-600' : 'text-red-600'
                                    }`}>
                                      {aluno.mediaAluno || 'N/A'}
                                    </span>
                                  </TableCell>
                                  <TableCell>
                                    <span className={`font-medium ${
                                      aluno.frequenciaAluno >= 75 ? 'text-green-600' : 'text-red-600'
                                    }`}>
                                      {aluno.frequenciaAluno || 0}%
                                    </span>
                                  </TableCell>
                                  <TableCell className="text-gray-600">
                                    {aluno.dataMatricula}
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}

            {turmas?.length === 0 && (
              <div className="text-center text-gray-500 py-8">
                <GraduationCap className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p>Nenhuma turma encontrada</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
