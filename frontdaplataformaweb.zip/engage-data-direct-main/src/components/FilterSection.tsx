
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useFilters } from "@/contexts/FilterContext";
import { useFilteredDepartments, useFilteredCursos, useFilteredProfessores } from "@/hooks/useFilteredData";

export const FilterSection = () => {
  const { filters, updateFilter, resetFilters } = useFilters();
  const { data: departamentos = [] } = useFilteredDepartments();
  const { data: cursos = [] } = useFilteredCursos();
  const { data: professores = [] } = useFilteredProfessores();

  return (
    <Card className="mb-8">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex items-center space-x-2">
            <Calendar className="w-4 h-4 text-gray-500" />
            <span className="text-sm font-medium text-gray-700">Filtros:</span>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4 flex-1">
            <Select value={filters.semestre} onValueChange={(value) => updateFilter('semestre', value)}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Selecione o semestre" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2025.1">2025.1</SelectItem>
                <SelectItem value="2024.2">2024.2</SelectItem>
                <SelectItem value="2024.1">2024.1</SelectItem>
                <SelectItem value="2023.2">2023.2</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.departamento} onValueChange={(value) => updateFilter('departamento', value)}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Selecione o departamento" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos-departamentos">Todos os Departamentos</SelectItem>
                {departamentos.map((dept) => (
                  <SelectItem key={dept.id} value={dept.codigo}>
                    {dept.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.curso} onValueChange={(value) => updateFilter('curso', value)}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Selecione o curso" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos-cursos">Todos os Cursos</SelectItem>
                {cursos.map((curso) => (
                  <SelectItem key={curso.id} value={curso.codigo}>
                    {curso.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.professor} onValueChange={(value) => updateFilter('professor', value)}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Selecione o professor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos-professores">Todos os Professores</SelectItem>
                {professores.map((prof) => (
                  <SelectItem key={prof.id} value={prof.id.toString()}>
                    {prof.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button 
              variant="outline" 
              size="sm" 
              onClick={resetFilters}
              className="flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Limpar
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
