
import React, { useRef, useState } from "react";
import { Button } from "@/components/ui/button";

interface AudioRecorderProps {
  onSend: (audioUrl: string, audioFile: File) => void;
  disabled?: boolean;
}

const AudioRecorder: React.FC<AudioRecorderProps> = ({ onSend, disabled }) => {
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [audioURL, setAudioURL] = useState<string | null>(null);
  const [audioFile, setAudioFile] = useState<File | null>(null);

  const handleStartRecording = async () => {
    setAudioURL(null);
    setAudioFile(null);
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorderRef.current = new MediaRecorder(stream);
    const audioChunks: BlobPart[] = [];

    mediaRecorderRef.current.ondataavailable = (e) => {
      audioChunks.push(e.data);
    };

    mediaRecorderRef.current.onstop = () => {
      const audioBlob = new Blob(audioChunks, { type: "audio/webm" });
      const url = URL.createObjectURL(audioBlob);
      setAudioURL(url);
      setAudioFile(new File([audioBlob], "gravacao.webm", { type: "audio/webm" }));
    };

    mediaRecorderRef.current.start();
    setIsRecording(true);
  };

  const handleStopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  };

  const handleSendAudio = () => {
    if (audioURL && audioFile) {
      onSend(audioURL, audioFile);
      setAudioURL(null);
      setAudioFile(null);
    }
  };

  return (
    <div className="flex items-center space-x-2">
      {!isRecording ? (
        <Button type="button" onClick={handleStartRecording} disabled={disabled}>
          🎤 Gravar áudio
        </Button>
      ) : (
        <Button type="button" onClick={handleStopRecording} variant="destructive">
          ◼️ Parar
        </Button>
      )}
      {audioURL && (
        <>
          <audio src={audioURL} controls className="h-8" />
          <Button type="button" onClick={handleSendAudio} size="sm">
            Enviar áudio
          </Button>
        </>
      )}
    </div>
  );
};

export default AudioRecorder;
