
import { useState } from "react";

export interface Message {
  id: string;
  text?: string;
  isUser: boolean;
  timestamp: Date;
  chartData?: any;
  imageUrl?: string;
  audioUrl?: string;
}

export interface Chat {
  id: string;
  name: string;
  messages: Message[];
}

export function useChats() {
  const [chats, setChats] = useState<Chat[]>(() => [
    {
      id: "1",
      name: "Chat 1",
      messages: [
        {
          id: "init",
          text: "Olá! Sou seu assistente de IA para análise de dados acadêmicos. Você pode me fazer perguntas como 'Mostre a taxa de frequência por departamento' ou 'Quais alunos estão em risco de reprovação neste semestre?'",
          isUser: false,
          timestamp: new Date(),
        },
      ],
    }
  ]);
  const [currentChatId, setCurrentChatId] = useState("1");

  const createNewChat = () => {
    const newId = Date.now().toString();
    const newChat: Chat = {
      id: newId,
      name: `Chat ${chats.length + 1}`,
      messages: [
        {
          id: "init_"+newId,
          text: "Olá! Novo chat iniciado.",
          isUser: false,
          timestamp: new Date(),
        }
      ]
    };
    setChats(prev => [newChat, ...prev]);
    setCurrentChatId(newId);
  };

  const selectChat = (id: string) => {
    setCurrentChatId(id);
  };

  const addMessageToCurrentChat = (message: Message) => {
    setChats(prev =>
      prev.map(chat =>
        chat.id === currentChatId
          ? { ...chat, messages: [...chat.messages, message] }
          : chat
      )
    );
  };

  const getCurrentChat = () => chats.find(c => c.id === currentChatId);

  return {
    chats,
    createNewChat,
    selectChat,
    addMessageToCurrentChat,
    getCurrentChat,
    currentChatId,
  };
}
