
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useFilters } from "@/contexts/FilterContext";

export const useFilteredDepartments = () => {
  return useQuery({
    queryKey: ['departamentos'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('departamento')
        .select('id, nome, codigo')
        .order('nome');
      
      if (error) throw error;
      return data || [];
    }
  });
};

export const useFilteredCursos = () => {
  const { filters } = useFilters();
  
  return useQuery({
    queryKey: ['cursos', filters.departamento],
    queryFn: async () => {
      let query = supabase
        .from('curso')
        .select('id, nome, codigo, departamento_id')
        .order('nome');
      
      if (filters.departamento !== 'todos-departamentos') {
        const { data: dept } = await supabase
          .from('departamento')
          .select('id')
          .eq('codigo', filters.departamento)
          .single();
        
        if (dept) {
          query = query.eq('departamento_id', dept.id);
        }
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    },
    enabled: true
  });
};

export const useFilteredProfessores = () => {
  const { filters } = useFilters();
  
  return useQuery({
    queryKey: ['professores', filters.departamento],
    queryFn: async () => {
      let query = supabase
        .from('professor')
        .select('id, nome, departamento_id')
        .eq('ativo', true)
        .order('nome');
      
      if (filters.departamento !== 'todos-departamentos') {
        const { data: dept } = await supabase
          .from('departamento')
          .select('id')
          .eq('codigo', filters.departamento)
          .single();
        
        if (dept) {
          query = query.eq('departamento_id', dept.id);
        }
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    }
  });
};
