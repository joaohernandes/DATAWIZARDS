
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface AcademicMetrics {
  taxaAprovacao: number;
  mediaGeral: number;
  taxaFrequencia: number;
  alunosRisco: number;
}

export const useAcademicMetrics = () => {
  return useQuery({
    queryKey: ['academic-metrics'],
    queryFn: async (): Promise<AcademicMetrics> => {
      console.log("Buscando métricas acadêmicas");

      // Buscar taxa de aprovação
      const { data: taxaAprovacao, error: errorTaxa } = await supabase
        .rpc('calcular_taxa_aprovacao');
      
      if (errorTaxa) {
        console.error("Erro ao buscar taxa de aprovação:", errorTaxa);
        throw errorTaxa;
      }

      // Buscar média geral
      const { data: mediaGeral, error: errorMedia } = await supabase
        .rpc('calcular_media_geral');
      
      if (errorMedia) {
        console.error("Erro ao buscar média geral:", errorMedia);
        throw errorMedia;
      }

      // Buscar taxa de frequência
      const { data: taxaFrequencia, error: errorFreq } = await supabase
        .rpc('calcular_taxa_frequencia');
      
      if (errorFreq) {
        console.error("Erro ao buscar taxa de frequência:", errorFreq);
        throw errorFreq;
      }

      // Buscar alunos em risco
      const { data: alunosRisco, error: errorRisco } = await supabase
        .rpc('contar_alunos_risco');
      
      if (errorRisco) {
        console.error("Erro ao buscar alunos em risco:", errorRisco);
        throw errorRisco;
      }

      console.log("Métricas obtidas:", {
        taxaAprovacao,
        mediaGeral,
        taxaFrequencia,
        alunosRisco
      });

      return {
        taxaAprovacao: taxaAprovacao || 0,
        mediaGeral: mediaGeral || 0,
        taxaFrequencia: taxaFrequencia || 0,
        alunosRisco: alunosRisco || 0
      };
    },
    refetchInterval: 30000,
  });
};
