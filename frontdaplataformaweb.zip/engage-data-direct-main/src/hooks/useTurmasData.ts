
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface TurmaData {
  turmaId: number;
  codigoTurma: string;
  nomeCurso: string;
  nomeProfessor: string;
  semestre: string;
  totalAlunos: number;
  mediaTurma: number;
  taxaFrequenciaTurma: number;
}

interface AlunoData {
  alunoId: number;
  nomeAluno: string;
  matriculaAluno: string;
  situacao: string;
  mediaAluno: number;
  frequenciaAluno: number;
  dataMatricula: string;
}

export const useTurmasData = () => {
  return useQuery({
    queryKey: ['turmas-resumo'],
    queryFn: async (): Promise<TurmaData[]> => {
      console.log("Buscando dados das turmas");
      
      const { data, error } = await supabase.rpc('obter_turmas_resumo');
      
      if (error) {
        console.error("Erro ao buscar turmas:", error);
        throw error;
      }

      return (data || []).map(item => ({
        turmaId: item.turma_id,
        codigoTurma: item.codigo_turma,
        nomeCurso: item.nome_curso,
        nomeProfessor: item.nome_professor,
        semestre: item.semestre,
        totalAlunos: item.total_alunos,
        mediaTurma: item.media_turma,
        taxaFrequenciaTurma: item.taxa_frequencia_turma
      }));
    },
    refetchInterval: 60000,
  });
};

export const useAlunosTurma = (turmaId: number | null) => {
  return useQuery({
    queryKey: ['alunos-turma', turmaId],
    queryFn: async (): Promise<AlunoData[]> => {
      if (!turmaId) return [];
      
      console.log("Buscando alunos da turma:", turmaId);
      
      const { data, error } = await supabase.rpc('obter_alunos_turma', {
        turma_id_param: turmaId
      });
      
      if (error) {
        console.error("Erro ao buscar alunos da turma:", error);
        throw error;
      }

      return (data || []).map(item => ({
        alunoId: item.aluno_id,
        nomeAluno: item.nome_aluno,
        matriculaAluno: item.matricula_aluno,
        situacao: item.situacao,
        mediaAluno: item.media_aluno,
        frequenciaAluno: item.frequencia_aluno,
        dataMatricula: new Date(item.data_matricula).toLocaleDateString('pt-BR')
      }));
    },
    enabled: !!turmaId,
    refetchInterval: 60000,
  });
};
