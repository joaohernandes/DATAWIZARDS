
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface PerformanceData {
  departamento: string;
  mediaNotas: number;
  frequencia: number;
}

interface SituacaoData {
  name: string;
  value: number;
  color: string;
}

export const useChartData = () => {
  const performanceQuery = useQuery({
    queryKey: ['performance-departamento'],
    queryFn: async (): Promise<PerformanceData[]> => {
      console.log("Buscando performance por departamento");
      
      const { data, error } = await supabase
        .rpc('obter_performance_departamento');
      
      if (error) {
        console.error("Erro ao buscar performance:", error);
        throw error;
      }

      return (data || []).map(item => ({
        departamento: item.departamento,
        mediaNotas: item.media_notas,
        frequencia: item.frequencia
      }));
    },
    refetchInterval: 60000,
  });

  const situacaoQuery = useQuery({
    queryKey: ['distribuicao-situacoes'],
    queryFn: async (): Promise<SituacaoData[]> => {
      console.log("Buscando distribuição de situações");
      
      const { data, error } = await supabase
        .rpc('obter_distribuicao_situacoes');
      
      if (error) {
        console.error("Erro ao buscar situações:", error);
        throw error;
      }

      const colorMap: { [key: string]: string } = {
        'Matriculado': '#1E3A8A',
        'Aprovado': '#10B981',
        'Reprovado': '#EF4444',
        'Trancado': '#F59E0B',
        'Cancelado': '#6B7280'
      };

      return (data || []).map(item => ({
        name: item.situacao,
        value: item.quantidade,
        color: colorMap[item.situacao] || '#6B7280'
      }));
    },
    refetchInterval: 60000,
  });

  return {
    performanceData: performanceQuery.data || [],
    situacaoData: situacaoQuery.data || [],
    isLoading: performanceQuery.isLoading || situacaoQuery.isLoading,
    error: performanceQuery.error || situacaoQuery.error
  };
};
