
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Calcula a taxa média de ocupação das turmas (alunos matriculados/capacidade).
 */
export const useOcupacaoMetrics = () => {
  return useQuery({
    queryKey: ['ocupacao-turmas'],
    queryFn: async (): Promise<{ taxaOcupacao: number }> => {
      console.log("Calculando ocupação");

      // Query para turmas
      const { data: turmas, error } = await supabase
        .from('turma')
        .select(`
          id, 
          capacidade,
          semestre,
          professor:professor_id(nome, departamento_id),
          curso:curso_id(nome, codigo)
        `)
        .order('id');

      if (error) throw error;

      // Busca de matrículas por turma
      const { data: matriculas, error: errorMatriculas } = await supabase
        .from('matricula')
        .select('turma_id');

      if (errorMatriculas) throw errorMatriculas;

      // Calcula ocupação por turma
      const ocupacao: { [turmaId: number]: { capacidade: number, matriculados: number } } = {};

      turmas?.forEach(t => {
        ocupacao[t.id] = { capacidade: t.capacidade, matriculados: 0 };
      });

      matriculas?.forEach(m => {
        if (ocupacao[m.turma_id]) {
          ocupacao[m.turma_id].matriculados += 1;
        }
      });

      // Calcula taxa média de ocupação
      const totalTurmas = Object.keys(ocupacao).length;
      const taxa =
        totalTurmas === 0
          ? 0
          : (
              Object.values(ocupacao).reduce((acc, el) => acc + (el.capacidade ? el.matriculados / el.capacidade : 0), 0) /
              totalTurmas
            ) * 100;

      return { taxaOcupacao: Math.round(taxa) };
    },
  });
};
