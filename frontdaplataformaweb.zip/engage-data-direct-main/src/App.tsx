
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import ChatPage from "./pages/ChatPage";
import AlertsPage from "./pages/AlertsPage";
import NotFound from "./pages/NotFound";
import { Navigation } from "./components/Navigation";
import AuthPage from "./pages/AuthPage";
import { AuthProvider, useAuth } from "./contexts/AuthContext";

const queryClient = new QueryClient();

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const path = window.location.pathname;
  if (loading) return <div className="flex justify-center items-center h-screen">Carregando...</div>;
  if (!user && path !== "/auth") {
    window.location.replace("/auth");
    return null;
  }
  if (user && path === "/auth") {
    window.location.replace("/");
    return null;
  }
  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <div className="min-h-screen bg-gray-50">
            <Navigation />
            <Routes>
              <Route
                path="/auth"
                element={
                  <ProtectedRoute>
                    <AuthPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="*"
                element={
                  <ProtectedRoute>
                    {/* Rotas protegidas */}
                    <Routes>
                      <Route path="/" element={<Index />} />
                      <Route path="/chat" element={<ChatPage />} />
                      <Route path="/alerts" element={<AlertsPage />} />
                      <Route path="*" element={<NotFound />} />
                    </Routes>
                  </ProtectedRoute>
                }
              />
            </Routes>
          </div>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;

